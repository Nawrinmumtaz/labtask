<!DOCTYPE html>
<html>
<head>
	<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>

<table style="width:50%">
 
  <tr>
  
      <td colspan="3"align="right"><img src="a.jpg" align="left"width="100px "height="100px"><h3 align="left">Company</h3>
   
	<a align="right" href="phome.php">Home</a>
	<a href="login.php">Login</a>
	<a href="reg.php">Registration</a></td>
  </tr>

  <tr>
    <td colspan="3"> <center><form>
		<fieldset style="width:50%">
			<legend><b>REGISTRATION</b></legend>
		
					Name: 
	<input type="text" name="name" size="20"  /><hr>
		Email: 
<input type="email" name="email" size="20" /><b>i</b><hr>	
			User Name: 
	<input type="text" name="uname" size="20"  /><hr>
Password:
<input type="password" name="" size="20" /><hr>
Confirm Password:
<input type="password" name="" size="20" /><hr>	
			<fieldset style="width:70%">
			<legend><b>Gender</b></legend>	
			<input type="radio" name="gender"/> Male
						<input type="radio" name="gender"/> Female
<input type="radio" name="gender"/> Other					</fieldset>
<hr>	
			<fieldset style="width:70%">
			<legend>Date Of Birth</legend>	
			<input type="date" name="" />				</fieldset><hr>
			<input type="submit" name="" value="submit">
			<input type="reset" name="" value="reset">
						<br><br>
					
		</fieldset><br><br>
	</form></center></td>
    
  </tr>
  <tr>
    <td colspan="3"><center><p>Copyright&copy;2017 <p></center>

</td>
    
  </tr>
</table>	
</body>
</html>