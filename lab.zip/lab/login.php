<!DOCTYPE html>
<html>
<head>
	<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>

<table style="width:50%">
 
  <tr>
  <td colspan="3"align="right"><img src="a.jpg" align="left"width="100px "height="100px"><h3 align="left">Company</h3>
   
	<a align="right" href="phome.php">Home</a>
	<a href="login.php">Login</a>
	<a href="reg.php">Registration</a></td>
  </tr>
  <tr>
    <td colspan="3"> <center><form>
		<fieldset style="width:50%">
			<legend><b>LOGIN</b></legend>
		

			User Name: 
	<input type="text" name="uname" size="20"  /><br><br>
Password:
<input type="password" name="" size="20" /><hr>

	<input type="checkbox" name="option[]">Remember Me<br>
			<input type="submit" name="" value="submit">
			<a align="right" href="pass.php">Forgot Password?</a>
						<br><br>
					
		</fieldset><br><br>
	</form></center></td>
    
  </tr>
  <tr>
    <td colspan="3"><center><p>Copyright&copy;2017 <p></center>

</td>
    
  </tr>
</table>	
</body>
</html>