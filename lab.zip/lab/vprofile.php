<!DOCTYPE html>
<html>
<head>
	<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>

<table style="width:50%">
 
  <tr>
  <td colspan="3"align="right"><img src="a.jpg" align="left"width="100px "height="100px"><h3 align="left">Company</h3>
   
Logged in as<a align="right" href="">Bob</a>|
	<a href="">Logout</a>&nbsp; &nbsp; 
	<br><br>
  </tr>
  <tr>
    <td>
	<b>Account</b>
		<ul>
				<li><a href="">Dashboard</a></li>
				<li><a href="">View Profile</a></li>
				<li><a href="">Edit Profile</a></li>
				<li><a href="">Edit Profile</a></li>
				<li><a href="">Edit Profile</a></li>
				<li><a href="">Logout</a></li>
			</ul>
	
	
	
	</td>
	<td colspan="2"><fieldset style="width:50%">
			<legend><b>PROFILE</b></legend>
		
					Name&nbsp;&nbsp;: Bob<hr>	
		Email&nbsp;&nbsp;: bob@gmail.com<hr>
			Gender&nbsp;&nbsp;: Male<hr>
			DateOfBirth&nbsp;&nbsp;: 19/09/18<hr>

			
						<br><br>
					
		</fieldset><br><br>
	</form></center>
	</td>
    
  </tr>
  <tr>
    <td colspan="3"><center><p>Copyright&copy;2017 <p></center>

</td>
    
  </tr>
</table>	
</body>
</html>